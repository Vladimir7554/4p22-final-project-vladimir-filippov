import React from 'react';

const BasketPage = () => {
    return (
        <div>
            BASKET PAGE
        </div>
    );
};

export default BasketPage;
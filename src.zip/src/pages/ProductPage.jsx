import React, {useState} from 'react';
import {useParams} from "react-router";

const ProductPage = () => {
    const { id } = useParams()
    const [productInfo, setProductInfo] = useState({})
    const [isLoading, setIsLoading] = useState(true)

    const fetchProductInf = () => {
      //  fetch()
    }

    if (isLoading)
        return <div>Загрузка...</div>

    return (
        <div>
            PRODUCT PAGE
        </div>
    );
};

export default ProductPage;
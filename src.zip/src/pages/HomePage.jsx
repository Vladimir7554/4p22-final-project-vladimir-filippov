import React from 'react';
import Catalog from "../views/Catalog/Catalog";

const HomePage = () => {
    return (
<Catalog />
    );
};

export default HomePage;
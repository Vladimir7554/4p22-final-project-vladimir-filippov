import React from 'react';

const FeedbackPage = () => {
    return (
        <div>
            FEEDBACK PAGE
        </div>
    );
};

export default FeedbackPage;